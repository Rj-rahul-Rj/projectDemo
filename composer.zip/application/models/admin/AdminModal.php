<?php

 require_once("CommanModal.php");

/**
 * 
 */
class AdminModal extends CommanModal
{
	
	
}
?>