<?php
function ageRangeData()
{
     $range  = array(array('min'=>10,'max'=>16,'lable'=>'10-16','use1'=>0,'key'=>'use1'),
                     array('min'=>16,'max'=>25,'lable'=>'16-25','use2'=>0,'key'=>'use2'),
                     array('min'=>25,'max'=>50,'lable'=>'25-50','use3'=>0,'key'=>'use3')
                    );
     return $range;
}

?>