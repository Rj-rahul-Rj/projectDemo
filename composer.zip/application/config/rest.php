<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$config['app_key'] = 'affricanfood#2020';
$config['app_secret'] = 'SHA15AHYVSGJ3#';
$config['allowed_method'] = array('signup','signupStepOne','signupStepTwo','verifyOtp','signin','forgotpassword','refresh','acountsetup','verifyForgotOtp','resetPassword','resendForgotOtp','getCountries','verifySeller','resendVerifyOtp','merchantplansAvailable','checkadminVerification','checkVerify','createUser','loginUser');
